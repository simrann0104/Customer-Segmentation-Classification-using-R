#RIDGELINE PLOT FOR SPENDING SCORE ACROSS DIFF. AGE GROUPS
# Load necessary libraries
library(readxl)
library(ggplot2)
library(dplyr)
library(ggridges)

# Load the dataset
form_data <- read_excel("Desktop/Projects/TableauProject/Customer Segmentation Classification.xlsx")
colnames(form_data) <- c("Timestamp", "Email_Address", "Name", "Age", "Gender", 
                         "Annual_Income", "Monthly_Expenses", "Spending_Score", 
                         "Favourite_Mall", "Shopping_Experience_Rating", "Region", 
                         "Loyalty_Score", "Category", "Date_Time")

# Remove rows with NA values in Age or Monthly_Expenses
form_data <- form_data %>%
  filter(!is.na(Age) & !is.na(Monthly_Expenses))

# Create age groups using cut
form_data$Age_Group <- cut(form_data$Age, 
                           breaks = seq(15, 100, by = 5), 
                           right = FALSE, 
                           labels = c("15-20", "20-25", "25-30", "30-35", "35-40", 
                                      "40-45", "45-50", "50-55", "55-60", 
                                      "60-65", "65-70", "70-75", "75-80", 
                                      "80-85", "85-90", "90-95", "95-100"))

# Create a ridgeline plot for spending score distribution across age groups
ggplot(form_data, aes(x = Spending_Score, y = Age_Group, fill = Age_Group)) +
  geom_density_ridges(scale = 2, alpha = 0.7) +
  labs(
    title = "Ridgeline Plot for Spending Score Distribution Across Age Groups",
    x = "Spending Score",
    y = "Age Group",
    fill = "Age Group"
  ) +
  theme_minimal() +
  theme(
    plot.title = element_text(size = 14, face = "bold", hjust = 0.5),
    axis.title = element_text(size = 12)
  )
