data<- read_excel("Desktop/TableauProject/Customer Segmentation Classification.xlsx")
summary(dt)
str(dt)
colnames(data) <- c("Date&Time", "Email", "Name", "Age", "Gender", "Annual_Income", "Monthly_Expenses", 
                    "Spending_Score", "Favourite_Mall", "Rating", "Region", "Loyalty_Score", "Category")
#step-by-step guide for checking simple linear regression
#Summarize the Dataset
summary(dt)
#Check Distribution with a Histogram
hist(dt$Spending_Score, main="Histogram of Spending Score", xlab="Spending Score", col="blue")
#Check Linearity
#same 1
plot(Spending_Score ~ Annual_Income, data = dt, main = "Spending Score vs Annual Income", xlab = "Annual Income", ylab = "Spending Score")
abline(lm(Spending_Score ~ Annual_Income, data = dt), col = "red") 
install.packages("ggplot2")
library(ggplot2)
#same 2
income_graph <- ggplot(dt, aes(x = Annual_Income, y = Spending_Score)) + geom_point() + geom_smooth(method="lm", col="red")
income_graph
#Fit a Simple Linear Regression Model
lm_model <- lm(Spending_Score ~ Annual_Income, data = dt)
summary(lm_model)
#Add Regression Equation to the Graph
install.packages("ggpubr")
library(ggpubr)
income_graph <- income_graph + stat_regline_equation(label.x = 3, label.y = 7)  # Adjust label.x and label.y to position the equation
income_graph
#Prepare the Graph for Publication
income_graph + theme_bw() + 
  labs(title = "Spending Score as a Function of Annual Income", 
       x = "Annual Income", 
       y = "Spending Score")
