#STACKED AREA CHART ACROSS REGIONS AND AGE GROUPS
# Load necessary libraries
library(readxl)
library(ggplot2)
library(dplyr)
library(forcats)
library(scales)

# Load the dataset
form_data <- read_excel("Desktop/Projects/TableauProject/Customer Segmentation Classification.xlsx")
colnames(form_data) <- c("Timestamp", "Email_Address", "Name", "Age", "Gender", 
                         "Annual_Income", "Monthly_Expenses", "Spending_Score", 
                         "Favourite_Mall", "Shopping_Experience_Rating", "Region", 
                         "Loyalty_Score", "Category", "Date_Time")

# Replace NA values in the 'Region' column with "Others"
form_data$Region <- ifelse(is.na(form_data$Region), "Others", form_data$Region)

# Re-create age groups
form_data$Age_Group <- cut(form_data$Age, 
                           breaks = c(15, 20, 25, 30, Inf), 
                           labels = c("15-20", "20-25", "25-30", "30+"), 
                           right = FALSE)

# Calculate average spending score by region and age group
region_age_spending <- form_data %>%
  group_by(Region, Age_Group) %>%
  summarise(Avg_Spending_Score = mean(Spending_Score, na.rm = TRUE))

# Ensure 'Region' is a factor with 'Others' first
region_age_spending$Region <- factor(region_age_spending$Region, 
                                     levels = c("Others", "New Delhi", "Amritsar", "Jalandhar", "Ludhiana", "Chandigarh"))

# Define custom colors
colors <- c("#264653", "#2A9D8F", "#E9C46A", "#F4A261", "#E76F51")

# Plot stacked area chart with custom color palette
ggplot(region_age_spending, aes(x = Region, y = Avg_Spending_Score, fill = Age_Group, group = Age_Group)) +
  geom_area(position = "stack", alpha = 0.8) +  # Increase transparency for a softer look
  scale_fill_manual(values = colors) +
  labs(title = "Spending Behaviors Across Regions and Age Groups",
       x = "Region", y = "Average Spending Score", fill = "Age Group") +
  theme_minimal(base_size = 14) +
  theme(
    plot.title = element_text(size = 16, face = "bold", hjust = 0.5),
    axis.text.x = element_text(angle = 45, hjust = 1),
    legend.position = "top",
    legend.title = element_text(face = "bold")
  )
