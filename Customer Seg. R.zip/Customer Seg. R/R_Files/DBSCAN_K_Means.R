#DBSCAN AND K MEANS
# Load necessary libraries
library(dbscan)
library(ggplot2)
library(dplyr)

# Assuming 'form_data' has the data loaded and prepared

# Apply DBSCAN on Annual Income (results already stored in DBSCAN_Income_Cluster)
dbscan_res <- dbscan(as.matrix(form_data$Annual_Income), eps = 100000, minPts = 5)
form_data$DBSCAN_Income_Cluster <- as.factor(dbscan_res$cluster)

# Apply K-Means on Monthly Expenses (results already stored in KMeans_Expenses_Cluster)
kmeans_res <- kmeans(form_data$Monthly_Expenses, centers = 3)
form_data$KMeans_Expenses_Cluster <- as.factor(kmeans_res$cluster)

# Plotting Annual Income vs Monthly Expenses with both DBSCAN and K-Means clusters
ggplot(form_data, aes(x = Annual_Income, y = Monthly_Expenses)) +
  geom_point(aes(color = DBSCAN_Income_Cluster, shape = KMeans_Expenses_Cluster), size = 3, alpha = 0.8) +
  scale_color_manual(values = c("red", "darkblue")) +  # Set red and dark blue colors
  labs(title = "Combined Clustering of Annual Income and Monthly Expenses",
       x = "Annual Income",
       y = "Monthly Expenses",
       color = "DBSCAN Cluster",
       shape = "K-Means Cluster") +
  theme_minimal() +
  theme(
    plot.title = element_text(size = 16, face = "bold"),
    axis.title = element_text(size = 12, color = "#333333"),
    axis.text = element_text(color = "#333333"),
    legend.position = "right"
  )

# Generating a contingency table to show the distribution across clusters
contingency_table <- table(form_data$DBSCAN_Income_Cluster, form_data$KMeans_Expenses_Cluster)
print(contingency_table)
