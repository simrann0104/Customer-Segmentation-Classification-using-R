# Load necessary libraries
install.packages("readxl")   # Uncomment if not already installed
install.packages("ggplot2")   # Uncomment if not already installed
install.packages("factoextra") # Uncomment if not already installed
library(readxl)
library(ggplot2)
library(factoextra)

# Load the dataset from an Excel file
file_path <- "Desktop/TableauProject/Customer Segmentation Classification.xlsx"
data <- read_excel(file_path)

# View the first few rows of the dataset
head(data)

# Select relevant numeric columns for clustering
data_numeric <- data[, c("Age", "Annual Income/Family Annual Income", 
                         "What is your Monthly Expenses?", "What is your Spending Score?")]

# Convert Annual Income to numeric (if necessary)
data_numeric$`Annual Income/Family Annual Income` <- as.numeric(data_numeric$`Annual Income/Family Annual Income`)

# Remove rows with missing values
data_numeric <- na.omit(data_numeric)

# Scale the data (standardization)
data_scaled <- scale(data_numeric)

# Set seed for reproducibility
set.seed(123)

# Apply K-means clustering with k = 3 and nstart = 25
km_res <- kmeans(data_scaled, centers = 3, nstart = 25)

# Print K-means results
print(km_res)

# Aggregate data by cluster to find the mean values of each variable in each cluster
cluster_means <- aggregate(data_numeric, by = list(Cluster = km_res$cluster), FUN = mean)
print(cluster_means)

# Add the cluster results to the original dataset
data$Cluster <- km_res$cluster

# View the first few rows of the dataset with cluster assignments
head(data)

# Visualize the clusters using ggplot for Age vs Spending Score
ggplot(data = data, mapping = aes(x = Age, y = `What is your Spending Score?`)) +
  geom_point(aes(color = factor(Cluster)), alpha = 0.7) + # Added alpha for better visibility
  labs(title = "Customer Segmentation (K-means Clustering)",
       x = "Age", 
       y = "Spending Score", 
       color = "Cluster") +
  theme_minimal()  # Use a minimal theme for aesthetics

# Visualize clusters using factoextra package
fviz_cluster(km_res, 
             data = data_scaled,  # Use the scaled data for clustering
             geom = "point",      # Use points for observations
             ellipse.type = "convex", # Draw convex hulls
             palette = c("#FF9999", "#66B2FF", "#99FF99"), # Custom color palette
             ggtheme = theme_minimal() + # Use a minimal theme
               theme(legend.position = "top")) + # Move legend position
  labs(title = "K-means Clustering of Customer Segmentation",
       subtitle = "Visualizing Clusters with Dimensionality Reduction",
       x = "Dimension 1 (Explained Variance: 48.3%)",
       y = "Dimension 2 (Explained Variance: 26.8%)",
       color = "Cluster")  # Clear axis labels

# Determine the optimal number of clusters using the Elbow method
fviz_nbclust(data_scaled, kmeans, method = "wss") +
  geom_vline(xintercept = 3, linetype = 2, color = "red") +  # Update intercept based on your findings
  labs(subtitle = "Elbow Method")

# Determine the optimal number of clusters using the Gap statistic method
fviz_nbclust(data_scaled, kmeans, nstart = 25, method = "gap_stat", nboot = 50) +
  labs(subtitle = "Gap Statistic Method")
