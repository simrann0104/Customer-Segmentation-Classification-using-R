#CLUSTERED BAR CHART FOR GENDER BASED SPENDING BEHAVIOUR ACROSS AGE GROUPS
# Load necessary libraries
library(dplyr)
library(ggplot2)
library(RColorBrewer)

# Replace NA values in the 'Spending_Score' column with zero (or any imputation method if desired)
form_data$Spending_Score[is.na(form_data$Spending_Score)] <- 0

# Create age groups
form_data$Age_Group <- cut(form_data$Age,
                           breaks = c(20, 25, 30, 35, 40, 45, 50, 55, Inf),
                           labels = c("20-25", "25-30", "30-35", "35-40", "40-45", "45-50", "50-55", "55+"),
                           right = FALSE)

# Calculate average spending score by gender and age group
gender_age_spending <- form_data %>%
  group_by(Age_Group, Gender) %>%
  summarise(Avg_Spending_Score = mean(Spending_Score, na.rm = TRUE)) %>%
  filter(!is.na(Age_Group))  # Remove rows with NA in Age_Group

# Define custom colors
gender_colors <- c("#264653", "#2A9D8F", "#E9C46A")

# Plot the clustered bar chart
ggplot(gender_age_spending, aes(x = Age_Group, y = Avg_Spending_Score, fill = Gender)) +
  geom_bar(stat = "identity", position = position_dodge(width = 0.8), width = 0.7) +
  scale_fill_manual(values = gender_colors) +  # Apply custom colors for gender
  labs(title = "Gender-Based Spending Patterns Across Age Groups",
       x = "Age Group", y = "Average Spending Score", fill = "Gender") +
  theme_minimal(base_size = 14) + 
  theme(
    plot.title = element_text(size = 18, face = "bold", hjust = 0.5, color = "#264653"),
    axis.text.x = element_text(size = 12, angle = 45, hjust = 1, color = "#2A9D8F"),
    axis.text.y = element_text(size = 12, color = "#2A9D8F"),
    axis.title = element_text(size = 14, face = "bold", color = "#264653"),
    legend.position = "top",
    legend.title = element_text(face = "bold", color = "#264653"),
    legend.text = element_text(color = "#2A9D8F"),
    panel.grid.major = element_line(color = "#E9C46A", linetype = "dashed"),
    panel.grid.minor = element_line(color = "#F4A261", linetype = "dotted")
  ) +
  geom_text(aes(label = round(Avg_Spending_Score, 1)), 
            position = position_dodge(width = 0.8), vjust = -0.5, size = 3.5, color = "#E76F51")  # Add labels for each bar
