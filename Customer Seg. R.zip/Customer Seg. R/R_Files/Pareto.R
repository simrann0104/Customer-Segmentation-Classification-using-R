#PARETO FOR AGE GROUPS VS SPENDING SCORE WITH CUM. PERCENTAGE
library(dplyr)
library(ggplot2)
library(forcats)

# Remove rows with NA values in both Age and Spending_Score columns
form_data <- form_data %>%
  filter(!is.na(Age) & !is.na(Spending_Score))

# Create age groups with the new age range (up to 55 and above)
form_data$Age_Group <- cut(form_data$Age, 
                           breaks = c(15, 20, 25, 30, 35, 40, 45, 50, 55, Inf), 
                           labels = c("15-20", "20-25", "25-30", "30-35", "35-40", "40-45", "45-50", "50-55", "55+"), 
                           right = FALSE)

# Calculate total spending score by age group and cumulative percentage
pareto_data <- form_data %>%
  group_by(Age_Group) %>%
  summarise(Total_Spending_Score = sum(Spending_Score, na.rm = TRUE)) %>%
  arrange(desc(Total_Spending_Score)) %>%
  mutate(Cumulative_Percent = cumsum(Total_Spending_Score) / sum(Total_Spending_Score) * 100)

# Define a color palette for each age group
age_group_colors <- c(
  "15-20" = "#264653",
  "20-25" = "#2A9D8F",
  "25-30" = "#E9C46A",
  "30-35" = "#F4A261",
  "35-40" = "#E76F51",
  "40-45" = "#264653",
  "45-50" = "#2A9D8F",
  "50-55" = "#E9C46A",
  "55+" = "#F4A261"
)

# Create the Pareto chart with age group-specific colors
ggplot(pareto_data, aes(x = fct_reorder(Age_Group, Total_Spending_Score, .desc = TRUE))) +
  geom_bar(aes(y = Total_Spending_Score, fill = Age_Group), stat = "identity") +
  geom_line(aes(y = Cumulative_Percent * max(Total_Spending_Score) / 100, group = 1), color = "#FF6347", size = 1) +
  geom_point(aes(y = Cumulative_Percent * max(Total_Spending_Score) / 100), color = "#FF6347", size = 2) +
  scale_fill_manual(values = age_group_colors) +  # Apply custom colors for age groups
  labs(title = "Pareto Chart for Age Groups vs. Spending Score with Cumulative Percentage",
       x = "Age Group", y = "Total Spending Score") +
  scale_y_continuous(
    sec.axis = sec_axis(~ . / max(pareto_data$Total_Spending_Score) * 100, name = "Cumulative Percentage (%)")
  ) +
  theme_minimal(base_size = 14) +
  theme(
    plot.title = element_text(size = 16, face = "bold", hjust = 0.5),
    axis.title.x = element_text(size = 12),
    axis.title.y = element_text(size = 12),
    axis.text.x = element_text(size = 10),
    legend.position = "none"
  )
