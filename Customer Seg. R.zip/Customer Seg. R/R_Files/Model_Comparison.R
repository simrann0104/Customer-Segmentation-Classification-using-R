#MODEL COMPARISON: Linear Reg.,Dec. Trees, R. Forest
#Customer Spending Prediction: Model Comparison Using Linear Regression, Decision Trees, and Random Forest
# Load necessary libraries
library(readxl)
library(dplyr)
library(ggplot2)
library(caret)
library(rpart)           # Decision tree
library(randomForest)    # Random forest
library(Metrics)         # For RMSE calculation

# Assuming 'form_data' has the data loaded and prepared

# Split data into training and testing sets
set.seed(123)
trainIndex <- createDataPartition(form_data$Spending_Score, p = 0.8, list = FALSE)
train_data <- form_data[trainIndex, ]
test_data <- form_data[-trainIndex, ]

# Model 1: Linear Regression
lm_model <- lm(Spending_Score ~ Age + Annual_Income + Monthly_Expenses + Shopping_Experience_Rating + Gender, data = train_data)
lm_pred <- predict(lm_model, newdata = test_data)

# Model 2: Decision Tree
tree_model <- rpart(Spending_Score ~ Age + Annual_Income + Monthly_Expenses + Shopping_Experience_Rating + Gender, data = train_data)
tree_pred <- predict(tree_model, newdata = test_data)

# Model 3: Random Forest
rf_model <- randomForest(Spending_Score ~ Age + Annual_Income + Monthly_Expenses + Shopping_Experience_Rating + Gender, data = train_data, ntree = 100)
rf_pred <- predict(rf_model, newdata = test_data)

# Model Evaluation - Calculate RMSE and R-squared
lm_rmse <- rmse(test_data$Spending_Score, lm_pred)
tree_rmse <- rmse(test_data$Spending_Score, tree_pred)
rf_rmse <- rmse(test_data$Spending_Score, rf_pred)

lm_r2 <- summary(lm_model)$r.squared
tree_r2 <- cor(test_data$Spending_Score, tree_pred)^2
rf_r2 <- cor(test_data$Spending_Score, rf_pred)^2

# Comparison of Models
comparison <- data.frame(
  Model = c("Linear Regression", "Decision Tree", "Random Forest"),
  RMSE = c(lm_rmse, tree_rmse, rf_rmse),
  R_Squared = c(lm_r2, tree_r2, rf_r2)
)
print(comparison)

# Visualization: Predictions vs Actual Values for each model
par(mfrow = c(1, 3))  # 1 row, 3 columns for side-by-side comparison

plot(test_data$Spending_Score, lm_pred, 
     main = "Linear Regression", xlab = "Actual", ylab = "Predicted", col = "blue", 
     pch = 19, cex = 1.3)  # Larger point size for visibility
abline(0, 1, col = "red", lwd = 2)  # Bold red line

plot(test_data$Spending_Score, tree_pred, 
     main = "Decision Tree", xlab = "Actual", ylab = "Predicted", col = "blue", 
     pch = 19, cex = 1.3)  # Larger point size for visibility
abline(0, 1, col = "red", lwd = 2)  # Bold red line

plot(test_data$Spending_Score, rf_pred, 
     main = "Random Forest", xlab = "Actual", ylab = "Predicted", col = "purple", 
     pch = 19, cex = 1.3)  # Larger point size for visibility
abline(0, 1, col = "red", lwd = 2)  # Bold red line

# Conclusion
best_model <- comparison[which.min(comparison$RMSE), ]
cat("Based on RMSE and R-squared values, the best model is:", best_model$Model, 
    "with RMSE =", best_model$RMSE, "and R-squared =", best_model$R_Squared)

# Visualization of RMSE values for each model
rmse_data <- data.frame(
  Model = c("Linear Regression", "Decision Tree", "Random Forest"),
  RMSE = c(lm_rmse, tree_rmse, rf_rmse)
)

# Bar plot for RMSE with bold bars and text
ggplot(rmse_data, aes(x = Model, y = RMSE, fill = Model)) +
  geom_bar(stat = "identity", width = 0.6, color = "black", lwd = 1) +  # Black border and thicker lines
  labs(title = "RMSE Comparison for Models",
       x = "Model",
       y = "RMSE") +
  theme_minimal(base_size = 14) +  # Increased base font size for readability
  theme(
    legend.position = "none",
    plot.title = element_text(face = "bold", size = 16),
    axis.title = element_text(face = "bold", size = 14),
    axis.text = element_text(size = 12)
  )
