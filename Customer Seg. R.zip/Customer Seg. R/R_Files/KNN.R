#KNN
# Load required libraries
library(readxl)
library(caret)
library(class)
library(ggplot2)

# Load the data file
form_data <- read_excel("Desktop/Projects/TableauProject/Customer Segmentation Classification.xlsx")
colnames(form_data) <- c("Timestamp", "Email_Address", "Name", "Age", "Gender", 
                         "Annual_Income", "Monthly_Expenses", "Spending_Score", 
                         "Favourite_Mall", "Shopping_Experience_Rating", "Region", 
                         "Loyalty_Score", "Category", "Date_Time")

# Group regions except specified ones as "Others"
form_data$Region <- ifelse(form_data$Region %in% c("New Delhi", "Amritsar", "Ludhiana", "Jalandhar", "Chandigarh"), 
                           form_data$Region, "Others")
form_data$Region <- as.factor(form_data$Region)

# Preprocess data
form_data$Loyalty_Score <- as.factor(form_data$Loyalty_Score)
form_data$Favourite_Mall <- as.factor(form_data$Favourite_Mall)

# Select relevant features for classification
form_data <- form_data[, c("Region", "Favourite_Mall", "Loyalty_Score")]

# Check if Loyalty_Score has more than one level
if (length(levels(form_data$Loyalty_Score)) > 1) {
  
  # Split data into training and testing sets
  set.seed(123)
  train_index <- createDataPartition(form_data$Loyalty_Score, p = 0.8, list = FALSE)
  train_data <- form_data[train_index, ]
  test_data <- form_data[-train_index, ]
  
  # Align factor levels in test data to match training data
  test_data$Region <- factor(test_data$Region, levels = levels(train_data$Region))
  test_data$Favourite_Mall <- factor(test_data$Favourite_Mall, levels = levels(train_data$Favourite_Mall))
  
  # Logistic Regression
  log_model <- glm(Loyalty_Score ~ Region + Favourite_Mall, data = train_data, family = "binomial")
  log_predictions <- predict(log_model, test_data, type = "response")
  log_predicted_classes <- ifelse(log_predictions > 0.5, "High", "Low")
  log_predicted_classes <- factor(log_predicted_classes, levels = levels(test_data$Loyalty_Score))
  
  # Logistic Regression Confusion Matrix
  if (length(unique(log_predicted_classes)) > 1 && length(unique(test_data$Loyalty_Score)) > 1) {
    log_confusion_matrix <- confusionMatrix(log_predicted_classes, test_data$Loyalty_Score)
    print("Logistic Regression Confusion Matrix:")
    print(log_confusion_matrix)
    
    # Visualization of Logistic Regression Confusion Matrix with custom colors
    log_cm_table <- as.data.frame(log_confusion_matrix$table)
    ggplot(log_cm_table, aes(x = Prediction, y = Reference, fill = Freq)) +
      geom_tile(color = "black") +
      geom_text(aes(label = Freq), color = "white", size = 5) +
      scale_fill_gradient2(low = "#264653", mid = "#2A9D8F", high = "#E9C46A", midpoint = median(log_cm_table$Freq)) +
      labs(
        title = "Confusion Matrix: Logistic Regression Model",
        subtitle = "Comparing Predicted and Actual Loyalty Scores",
        x = "Predicted Loyalty Score",
        y = "Actual Loyalty Score"
      ) +
      theme_minimal(base_family = "Helvetica") +
      theme(
        plot.background = element_rect(fill = "black", color = NA),
        panel.background = element_rect(fill = "#1E1E1E", color = NA),
        plot.title = element_text(face = "bold", hjust = 0.5, color = "white"),
        plot.subtitle = element_text(hjust = 0.5, color = "lightgray"),
        axis.text = element_text(size = 10, color = "white"),
        legend.position = "right"
      )
  } else {
    print("Warning: Not all classes are present in predictions or actual test data.")
  }
  
  # K-Nearest Neighbors (KNN)
  train_x <- train_data[, c("Region", "Favourite_Mall")]
  train_y <- train_data$Loyalty_Score
  test_x <- test_data[, c("Region", "Favourite_Mall")]
  test_y <- test_data$Loyalty_Score
  
  # Convert factors to numeric
  train_x[] <- lapply(train_x, as.numeric)
  test_x[] <- lapply(test_x, as.numeric)
  
  # KNN Model
  knn_predictions <- knn(train = train_x, test = test_x, cl = train_y, k = 3)
  
  # KNN Confusion Matrix
  if (length(unique(knn_predictions)) > 1 && length(unique(test_y)) > 1) {
    knn_confusion_matrix <- confusionMatrix(knn_predictions, test_y)
    print("KNN Confusion Matrix:")
    print(knn_confusion_matrix)
    
    # Visualization of KNN Confusion Matrix with custom colors
    knn_cm_table <- as.data.frame(knn_confusion_matrix$table)
    ggplot(knn_cm_table, aes(x = Prediction, y = Reference, fill = Freq)) +
      geom_tile(color = "white") +
      geom_text(aes(label = Freq), color = "white", size = 5) +
      scale_fill_gradient2(low = "#264653", mid = "#2A9D8F", high = "#E9C46A", midpoint = median(knn_cm_table$Freq)) +
      labs(
        title = "Confusion Matrix: K-Nearest Neighbors (KNN) Model",
        subtitle = "Comparing Predicted and Actual Loyalty Scores",
        x = "Predicted Loyalty Score",
        y = "Actual Loyalty Score"
      ) +
      theme_minimal(base_family = "Helvetica") +
      theme(
        plot.background = element_rect(fill = "white", color = NA),
        panel.background = element_rect(fill = "#1E1E1E", color = NA),
        plot.title = element_text(face = "bold", hjust = 0.5, color = "white"),
        plot.subtitle = element_text(hjust = 0.5, color = "black"),
        axis.text = element_text(size = 10, color = "black"),
        legend.position = "right"
      )
  } else {
    print("Warning: Not all classes are present in predictions or actual test data.")
  }
  
} else {
  print("Error: The target variable 'Loyalty_Score' has only one level, making classification impossible.")
}
