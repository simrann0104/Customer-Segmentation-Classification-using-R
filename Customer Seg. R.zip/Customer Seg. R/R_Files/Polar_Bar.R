#spending score across different mall(polar bar plot)
# Load necessary libraries
library(dplyr)
library(readxl)
library(ggplot2)
library(viridis)

# Load the data file
form_data <- read_excel("Desktop/Projects/TableauProject/Customer Segmentation Classification.xlsx")
colnames(form_data) <- c("Timestamp", "Email_Address", "Name", "Age", "Gender", 
                         "Annual_Income", "Monthly_Expenses", "Spending_Score", 
                         "Favourite_Mall", "Shopping_Experience_Rating", "Region", 
                         "Loyalty_Score", "Category", "Date_Time")

# Aggregate data by Favourite Mall
mall_spending_data <- form_data %>%
  group_by(Favourite_Mall) %>%
  summarize(Total_Spending_Score = sum(Spending_Score, na.rm = TRUE), .groups = 'drop')

# Create polar bar plot
ggplot(mall_spending_data, aes(x = Favourite_Mall, y = Total_Spending_Score, fill = Favourite_Mall)) +
  geom_bar(stat = "identity") +
  coord_polar(start = 0) +
  labs(title = "Spending Patterns Across Different Malls") +
  scale_fill_viridis_d(option = "viridis") +  # Using the "viridis" color palette
  theme_minimal() +
  theme(
    plot.title = element_text(size = 16, face = "bold", hjust = 0.5),  # Center the title
    legend.position = "bottom",
    legend.title = element_blank()  # Remove legend title for a cleaner look
  )
