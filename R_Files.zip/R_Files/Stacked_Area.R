#stacked area chart for "Region-Wise Consumer Spending Distribution Across Categories"
# Load necessary libraries
library(fmsb)
library(dplyr)
library(readxl)
library(ggplot2)

# Load the data file
form_data <- read_excel("Desktop/Projects/TableauProject/Customer Segmentation Classification.xlsx")
colnames(form_data) <- c("Timestamp", "Email_Address", "Name", "Age", "Gender", 
                         "Annual_Income", "Monthly_Expenses", "Spending_Score", 
                         "Favourite_Mall", "Shopping_Experience_Rating", "Region", 
                         "Loyalty_Score", "Category", "Date_Time")

# Group other regions as "Others"
spending_data <- form_data %>%
  mutate(Region = ifelse(Region %in% c("New Delhi", "Chandigarh", "Amritsar", "Jalandhar", "Ludhiana"),
                         Region, "Others")) %>%
  group_by(Region, Category) %>%
  summarize(Total_Spending_Score = sum(Spending_Score, na.rm = TRUE), .groups = 'drop')

# Convert Region to a factor, then to numeric for continuous plotting
spending_data$Region <- factor(spending_data$Region, levels = c("New Delhi", "Chandigarh", "Amritsar", "Jalandhar", "Ludhiana", "Others"))
spending_data$Region_numeric <- as.numeric(spending_data$Region)

# Custom color palette
dark_colors <- c("#264653", "#2A9D8F", "#E9C46A", "#F4A261", "#E76F51")

# Create the stacked area chart
ggplot(spending_data, aes(x = Region_numeric, y = Total_Spending_Score, fill = Category, group = Category)) +
  geom_area(position = "stack", alpha = 0.9) +
  scale_fill_manual(values = dark_colors) +
  scale_x_continuous(breaks = 1:6, labels = levels(spending_data$Region)) +  # Map numeric x-axis back to Region labels
  labs(title = "Region-Wise Consumer Spending Distribution Across Categories",
       x = "Region", y = "Spending Score") +
  theme_minimal() +
  theme(legend.position = "bottom")
