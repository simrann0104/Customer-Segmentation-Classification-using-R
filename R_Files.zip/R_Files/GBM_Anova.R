#MODEL COMPARISON GBM, and ANOVA
#"Model Performance Comparison: GBM, and ANOVA Using RMSE"
# Load necessary libraries
library(readxl)
library(dplyr)
library(caret)           # For GBM
library(gbm)             # For GBM
library(Metrics)         # For RMSE calculation
library(ggplot2)         # For visualization
library(class)           # For KNN
library(DescTools)       # For ANOVA

# Initialization and Import Data
form_data <- read_excel("Desktop/Projects/TableauProject/Customer Segmentation Classification.xlsx")
colnames(form_data) <- c("Timestamp", "Email_Address", "Name", "Age", "Gender", 
                         "Annual_Income", "Monthly_Expenses", "Spending_Score", 
                         "Favourite_Mall", "Shopping_Experience_Rating", "Region", 
                         "Loyalty_Score", "Category", "Date_Time")

# Data Cleaning and Transformation
form_data <- form_data %>% 
  mutate(across(c(Age, Annual_Income, Monthly_Expenses, Spending_Score), as.numeric),
         Gender = factor(Gender),
         Region = factor(Region))

# Handling missing values (Example: replace missing Spending_Score with mean)
form_data$Spending_Score[is.na(form_data$Spending_Score)] <- mean(form_data$Spending_Score, na.rm = TRUE)

# Feature Engineering (optional, if needed for better results)
form_data <- form_data %>%
  mutate(Income_to_Expense_Ratio = Annual_Income / Monthly_Expenses,
         Date_Time = as.Date(Date_Time, format = "%m/%d/%Y"))

# Split data into training and testing sets
set.seed(123)
trainIndex <- createDataPartition(form_data$Spending_Score, p = 0.8, list = FALSE)
train_data <- form_data[trainIndex, ]
test_data <- form_data[-trainIndex, ]

# 2. GBM Model (Gradient Boosting Machine)
gbm_model <- gbm(Spending_Score ~ Annual_Income, data = train_data, 
                 distribution = "gaussian", n.trees = 100, interaction.depth = 3)
gbm_pred <- predict(gbm_model, newdata = test_data, n.trees = 100)

# 3. ANOVA Model (Analysis of Variance)
anova_model <- aov(Spending_Score ~ Annual_Income, data = train_data)
anova_pred <- predict(anova_model, newdata = test_data)

# Model Evaluation - Calculate RMSE
gbm_rmse <- rmse(test_data$Spending_Score, gbm_pred)
anova_rmse <- rmse(test_data$Spending_Score, anova_pred)

# Model Evaluation - Calculate R-squared
gbm_r2 <- cor(test_data$Spending_Score, gbm_pred)^2
anova_r2 <- cor(test_data$Spending_Score, anova_pred)^2

# Comparison of Models
comparison <- data.frame(
  Model = c( "GBM", "ANOVA"),
  RMSE = c(gbm_rmse, anova_rmse),
  R_Squared = c(gbm_r2, anova_r2)
)
print(comparison)

# Visualization: Predictions vs Actual Values for each model
par(mfrow = c(1, 2))  # 1 row, 3 columns for side-by-side comparison

# GBM Plot
plot(test_data$Spending_Score, gbm_pred, 
     main = "GBM", xlab = "Actual", ylab = "Predicted", col = "darkgreen", pch = 19, cex = 1.5)
abline(0, 1, col = "red", lwd = 2)  # Bold line for GBM

# ANOVA Plot
plot(test_data$Spending_Score, anova_pred, 
     main = "ANOVA", xlab = "Actual", ylab = "Predicted", col = "purple", pch = 19, cex = 1.5)
abline(0, 1, col = "red", lwd = 2)  # Bold line for ANOVA

# Visualization of RMSE values for each model
rmse_data <- data.frame(
  Model = c("GBM", "ANOVA"),
  RMSE = c( gbm_rmse, anova_rmse)
)

# Bar plot with bold labels and larger text
ggplot(rmse_data, aes(x = Model, y = RMSE, fill = Model)) +
  geom_bar(stat = "identity", width = 0.6) +
  labs(title = "RMSE Comparison for GBM, and ANOVA Models",
       x = "Model",
       y = "RMSE") +
  theme_minimal() +
  theme(
    legend.position = "none",
    text = element_text(size = 14, face = "bold"),  # Larger and bold text
    axis.title = element_text(size = 16, face = "bold"),
    plot.title = element_text(size = 18, face = "bold")
  )

# Conclusion
best_model <- comparison[which.min(comparison$RMSE), ]
cat("Based on RMSE and R-squared values, the best model is:", best_model$Model, 
    "with RMSE =", best_model$RMSE, "and R-squared =", best_model$R_Squared)
