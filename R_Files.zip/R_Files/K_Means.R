#K MEANS
#"Customer Segmentation Analysis Using K-Means Clustering with Optimal Cluster Determination"
# Load necessary libraries
library(readxl)
library(ggplot2)
library(factoextra)

# Load the dataset from an Excel file
file_path <- "Desktop/Projects/TableauProject/Customer Segmentation Classification.xlsx"
data <- read_excel(file_path)

# Select relevant numeric columns for clustering
data_numeric <- data[, c("Age", "Annual Income/Family Annual Income", 
                         "What is your Monthly Expenses?", "What is your Spending Score?")]

# Convert Annual Income to numeric (if necessary)
data_numeric$`Annual Income/Family Annual Income` <- as.numeric(data_numeric$`Annual Income/Family Annual Income`)

# Remove rows with missing values
data_numeric <- na.omit(data_numeric)

# Scale the data (standardization)
data_scaled <- scale(data_numeric)

# Set seed for reproducibility
set.seed(123)

# Apply K-means clustering with k = 3 and nstart = 25
km_res <- kmeans(data_scaled, centers = 3, nstart = 25)

# Add the cluster results to the original dataset
data$Cluster <- factor(km_res$cluster, levels = c(1, 2, 3), 
                       labels = c("Low Spenders", "Moderate Spenders", "High Spenders"))

# Plot Age vs. Spending Score with clusters and bold headings
ggplot(data = data, mapping = aes(x = Age, y = `What is your Spending Score?`)) +
  geom_point(aes(color = Cluster), alpha = 0.8, size = 3) +
  scale_color_manual(values = c("#2A9D8F", "red", "orange")) +
  labs(title = "Customer Segmentation (K-means Clustering)",
       x = "Age", 
       y = "Spending Score", 
       color = "Clusters") +
  theme_minimal(base_size = 15) +
  theme(
    plot.title = element_text(size = 18, face = "bold", color = "#333333", hjust = 0.5),
    axis.title = element_text(size = 14, color = "#333333"),
    axis.text = element_text(size = 12, color = "#333333"),
    panel.background = element_rect(fill = "#f2f2f2", color = NA),
    legend.position = "top",
    legend.title = element_text(face = "bold")
  )

# Visualize clusters using factoextra package with bold headings
fviz_cluster(km_res, 
             data = data_scaled,
             geom = "point",      
             ellipse.type = "convex",
             palette = c("#2a9d85", "#871f78", "red"),
             ggtheme = theme_minimal() + 
               theme(legend.position = "top",
                     plot.title = element_text(face = "bold", size = 16),
                     plot.subtitle = element_text(face = "bold", size = 14))) +
  labs(title = "K-means Clustering of Customer Segmentation",
       subtitle = "Visualizing Clusters with Dimensionality Reduction",
       x = "Dimension 1 (Explained Variance: 48.3%)",
       y = "Dimension 2 (Explained Variance: 26.8%)",
       color = "Cluster")
# Elbow Method with dark background and light lines
fviz_nbclust(data_scaled, kmeans, method = "wss") +
  geom_vline(xintercept = 3, linetype = 2, color = "red", size = 1.2) +  # Light vline
  geom_line(size = 1.2, color = "yellow") +  # Yellow WSS curve
  labs(title = "Determining Optimal Clusters Using Elbow Method") +
  theme_minimal() +
  theme(
    plot.title = element_text(face = "bold", size = 16, color = "white"),
    plot.subtitle = element_text(face = "bold", size = 14, color = "white"),
    axis.title = element_text(color = "white"),
    axis.text = element_text(color = "white"),
    panel.background = element_rect(fill = "#333333", color = NA),  # Dark gray background
    plot.background = element_rect(fill = "#333333", color = NA),
    panel.grid.major = element_line(color = "#444444"),  # Subtle grid lines
    panel.grid.minor = element_line(color = "#444444")
  )

# Gap Statistic Method with dark background and yellow line
fviz_nbclust(data_scaled, kmeans, nstart = 25, method = "gap_stat", nboot = 50) +
  geom_line(size = 1.2, color = "yellow") +  # Yellow gap statistic curve
  labs(title = "Optimal Clusters Using Gap Statistic Method") +
  theme_minimal() +
  theme(
    plot.title = element_text(face = "bold", size = 16, color = "white"),
    plot.subtitle = element_text(face = "bold", size = 14, color = "white"),
    axis.title = element_text(color = "white"),
    axis.text = element_text(color = "white"),
    panel.background = element_rect(fill = "#333333", color = NA),  # Dark gray background
    plot.background = element_rect(fill = "#333333", color = NA),
    panel.grid.major = element_line(color = "#444444"),  # Subtle grid lines
    panel.grid.minor = element_line(color = "#444444")
  )
