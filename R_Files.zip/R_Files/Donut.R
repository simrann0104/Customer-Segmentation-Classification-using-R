#DONUT CHART
# Load necessary libraries
#install.packages("tidyverse")
library(tidyverse)
library(caret)
library(class)
library(readxl)
library(ggplot2)

# Load the data file
form_data <- read_excel("Desktop/Projects/TableauProject/Customer Segmentation Classification.xlsx")
colnames(form_data) <- c("Timestamp", "Email_Address", "Name", "Age", "Gender", 
                         "Annual_Income", "Monthly_Expenses", "Spending_Score", 
                         "Favourite_Mall", "Shopping_Experience_Rating", "Region", 
                         "Loyalty_Score", "Category", "Date_Time")

# Step 1: Data Preprocessing
# Select relevant columns and drop missing values
data <- form_data %>%
  select(Category, Spending_Score) %>%
  drop_na()

# Step 2: Summarize the Spending Score by Category
spending_summary <- data %>%
  group_by(Category) %>%
  summarize(Total_Spending = sum(Spending_Score, na.rm = TRUE)) %>%
  ungroup()

# Step 3: Calculate Percentage for Donut Chart
spending_summary <- spending_summary %>%
  mutate(Percentage = Total_Spending / sum(Total_Spending) * 100,
         Label = paste0(Category, "\n", round(Percentage, 1), "%"))

# Step 4: Create a Donut Chart with Darker Colors and Smaller Labels
ggplot(spending_summary, aes(x = 2, y = Total_Spending, fill = Category)) +
  geom_bar(stat = "identity", width = 1, color = "white") +
  coord_polar(theta = "y") +
  xlim(0.5, 2.5) +  # Create space for the donut hole
  geom_text(aes(label = Label), 
            position = position_stack(vjust = 0.5), 
            size = 3.5,  # Reduced font size for better fit
            color = "white", 
            lineheight = 0.9) +  # Adjust line height for better spacing
  labs(
    title = "Customer Spending Patterns by Category",
    subtitle = "Donut Chart Visualization",
    fill = "Category"
  ) +
  theme_void() +
  theme(
    plot.title = element_text(hjust = 0.5, face = "bold", size = 16),
    plot.subtitle = element_text(hjust = 0.5, size = 12),
    legend.position = "right"
  ) +
  scale_fill_manual(values = c(
    "Fashion and Beauty" = "#264653",    # Darker purple
    "Furniture & Decor" = "#F4A261",     # Rich dark orange
    "Grocery & Electrical Supplies" = "#1f78b4",  # Deep blue
    "Movie & Munch" = "#2A9D8F",         # Darker green
    "Others" = "#e31a1c"                 # Bold red
  ))
